clear;
addpath('tSVD','proxFunctions','solvers','twist','data');
addpath('ClusteringMeasure', 'LRR', 'Nuclear_norm_l21_Algorithm', 'unlocbox');

load('yale.mat'); 

cls_num = length(unique(gt));
%% Note: each column is an sample (same as in LRR)
%% 
%data preparation...
 X{1} = X3; X{2} = X2; X{3} = X1;
 for v=1:3
    [X{v}]=NormalizeData(X{v});
 end

% Initialize...
K = length(X); N = size(X{1},2); %sample number

MaxACC=0;
lambda = [];
result = [];
Final = [];
pref_1 = [];
pref_2 = [];


lambda1 = 0.1;
lambda2 = 0.1;
u = 0.6;
% ORL      0.4        0.1      0.4
% yale      0.1        0.1      0.6
% yaleB    1000      1000      1.1
% BBC       0.001      0.1    1.9
% NGs        5      0.6       0.95

for k=1:K
    Z{k} = zeros(N,N); 
    A{k} = zeros(N,N); %权重w
    E1{k} = zeros(size(X{k},1),N); 
    Y1{k} = zeros(size(X{k},1),N); 
end

for a=1:2
    W{a} = zeros(N,N);
    G{a} = zeros(N,N);
end

S = zeros(N);
C = zeros(N,N);
E2=zeros(N);
Y2=zeros(N,N);

w = zeros(N*N*2,1);
g = zeros(N*N*2,1);
dim1 = N;dim2 = N;dim3 = 2;
myNorm = 'tSVD_1';
sX = [N, N, 2];

%set Default
parOP         =    false;
ABSTOL        =    1e-6;
RELTOL        =    1e-4;

Isconverg = 0;epson = 1e-7;
iter = 0;
mu1 = 10e-5; max_mu1 = 10e10; pho_mu1 = 2;
mu2 = 10e-5; max_mu2 = 10e10; pho_mu2 = 2;
rho = 0.0001; max_rho = 10e12; pho_rho = 2;
tic;

while(Isconverg == 0)
%     fprintf('----processing iter %d--------\n', iter+1);
    
    %1 update Z^k 
    for k=1:K      
        tmp1 = 2*A{k}*S + X{k}'*Y1{k} + mu1*X{k}'*X{k} - mu1*X{k}'*E1{k};
        tmp2 = 2*A{k} + mu1*X{k}'*X{k};
        Z{k} = pinv(tmp2)*tmp1;
    end

    %2 update A^k 
    for k=1:K      
        tmp3 = norm(S-Z{k},inf);
        A{k} = 1/(2*tmp3);
    end

    %3 update S 
    tmp4 = 0;
    tmp5 = 0;
    for k=1:K      
        tmp4 = tmp4 + A{k}*Z{k};
        tmp5 = tmp5 + A{k};
    end
    S_left = 2*tmp5 + mu2*eye(N,N) + rho*eye(N,N);
    S_right = mu2*C*C' - mu2*C - mu2*C';
    S_all = 2*tmp4 - Y2 + Y2*C' + mu2*E2 - mu2*E2*C' - W{1} + rho*G{1};
    S = lyap(S_left,S_right,S_all);
    S = SimplexProj( S'/u);  
    S = S'*u;

    %4 update C 
    tmp6 = S'*Y2 + mu2*S'*S - mu2*S'*E2 - W{2} + rho*G{2};
    tmp7 = mu2*S'*S + rho*eye(N,N);
    C = pinv(tmp7)*tmp6;

    %5 update E1^K
    tmp8 = 0;
    tmp9 = 2*lambda1*eye(N,N) + mu1*eye(N,N);
    for k=1:K      
        tmp8 = Y1{k} + mu1*X{k} - mu1*X{k}*Z{k};
        E1{k} = tmp8*pinv(tmp9);
    end

    %6 update E2
    tmp10 = Y2 + mu2*S - mu2*S*C;
    tmp11 = 2*lambda1*eye(N,N) + mu2*eye(N,N);
    E2 = tmp10*pinv(tmp11);
    
    %7 update G
    H_tensor = cat(3, S, C);
    W_tensor = cat(3, W{:,:});
    h = H_tensor(:);
    w = W_tensor(:);  
    [g, objV] = wshrinkObj(h + 1/rho*w,lambda2/rho,sX,0,3)   ;
    G_tensor = reshape(g, sX);
    
    %8 update W
    w = w + rho*(h - g);

    %9 update Y1{k},Y2
    for k=1:K
    Y1{k}=Y1{k} + mu1*(X{k}-X{k}*Z{k}-E1{k});
    end
    Y2=Y2+mu2*(S-S*C-E2);

    %record the iteration information
    history.objval(iter+1)   =  objV;

    %% coverge condition
    Isconverg = 1;
    for k=1:K
        if (norm(X{k}-X{k}*Z{k}-E1{k},inf)>epson)
            history.norm_1 = norm(X{k}-X{k}*Z{k}-E1{k},inf);
%             fprintf('    norm_1 %7.10f    ', history.norm_1);

            Isconverg = 0;
        end
    end
         if (norm(S-S*C-E2,inf)>epson) %%%%% 
            history.norm_2 = norm(S-S*C-E2,inf);
%             fprintf('\n    norm_2 %7.10f    \n', history.norm_2);

            Isconverg = 0;
         end
       
        for a = 1:2
        G{a} = G_tensor(:,:,a);
        W_tensor = reshape(w, sX);
        W{a} = W_tensor(:,:,a);
        end
        
        if (norm(S-G{1},inf)>epson) %%% H-G
            history.norm_S_G = norm(S-G{1},inf);
%           fprintf('   norm_S_G %7.10f    ', history.norm_S_G);

            Isconverg = 0;
        end
        if (norm(C-G{2},inf)>epson) %%% H-G
            history.norm_C_G = norm(C-G{2},inf);
%           fprintf('   norm_C_G %7.10f    \n', history.norm_C_G);

            Isconverg = 0;
        end

       
    if (iter>200)
        Isconverg  = 1;
    end
    iter = iter + 1;
    mu1 = min(mu1*pho_mu1, max_mu1);
    mu2 = min(mu2*pho_mu2, max_mu2);
    rho = min(rho*pho_rho, max_rho);
end

 S1 =  abs(C)+abs(C');

pre_labels_C = SpectralClustering(S1,cls_num);
result = Clustering8Measure(double(gt), pre_labels_C)*100;
Final = [Final;lambda,result];

if(MaxACC<result(1))
    MaxACC = result(1);
end

fprintf('lambda1 %.4f lambda2 %.4f u %.2f  ACC %.3f  MaxACC %.3f  \n', lambda1,lambda2,u,result(1),MaxACC);
toc;

clear A;




